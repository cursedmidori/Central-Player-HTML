# Central Player HTML WebView APK

Este projeto NÃO usa Flutter.

Ele cria um APK Android nativo com WebView e carrega o arquivo:

central_player_mobile.html

## Por que existe?

Se o APK aparece como "Flutter Demo Home Page", significa que o GitHub Actions compilou o template padrão do Flutter, não o HTML da Central do Player.

Esta versão evita isso completamente.

## Como usar

1. Crie um repositório novo.
2. Envie estes arquivos:
   - central_player_mobile.html
   - .github/workflows/build-apk.yml
3. Vá em Actions.
4. Rode "Gerar APK HTML WebView".
5. Baixe o artefato "central-player-html-webview-apk".

## Importar/Exportar JSON

- Importar JSON usa input de arquivo do HTML, com suporte WebView nativo.
- Exportar JSON usa ponte Android nativa e abre a tela de salvar arquivo.

## Importação Naloi.json

Esta versão reconhece o formato exportado por fichas com chaves como `nome`, `classe`, `trilha`, `nex`, `nivel`, `attr`, `stats`, `skills`, `atk`, `rit`, `hab` e `inv`.

O importador converte:
- `attr: [agi, for, int, pre, vig]` para atributos da central.
- `stats.pvA/pvM`, `peA/peM`, `pdA/pdM`, `sanA/sanM`.
- `skills.*.g` como treino e `skills.*.b` como bônus.
- `atk` e armas do `inv` para Armas.
- `rit` para Rituais.
- `hab` para Poderes.
- proteções e itens do `inv`.
